﻿using System.Windows.Media;

namespace CourseWork_Project
{
    public class LightLine
    {
        public double X1 { get; set; }
        public double Y1 { get; set; }
        public double X2 { get; set; }
        public double Y2 { get; set; }

        public Brush Stroke { get; set; }
    }
}