﻿namespace CourseWork_Project.Rendering
{
    public enum DrawingMode
    {
        Loop,
        Seperate
    }
}
