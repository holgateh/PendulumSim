﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CourseWork_Project.Rendering.Draw.Text
{
    public class LightText
    {
        public string Text { get; set; }
        public Vec2 Position { get; set; } = new Vec2();
    }
}
