﻿namespace CourseWork_Project.Simulations
{
    public struct Derivative
    {
        public double deltaDisplacement;
        public double deltaVelocity;
    }

}
