﻿namespace CourseWork_Project.Simulations
{
    public class State
    {
        public double Displacement { get; set; }
        public double Velocity { get; set; }
        public double Acceleration { get; set; }
    }

}
