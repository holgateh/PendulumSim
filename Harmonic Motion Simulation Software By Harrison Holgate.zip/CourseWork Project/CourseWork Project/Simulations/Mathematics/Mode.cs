﻿//Harrison Holgate Course Work Project


namespace CourseWork_Project
{
    public enum Mode
    {
        Graph,
        SpringPendulumSimulation,
        PendulumSimulation,
        DoublePendulum
    }
}
