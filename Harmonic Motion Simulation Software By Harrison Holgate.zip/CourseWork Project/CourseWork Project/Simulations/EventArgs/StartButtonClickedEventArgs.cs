﻿using System;

namespace CourseWork_Project
{
    public class StartButtonClickedEventArgs : EventArgs
    {
        public bool State { get; set; }
    }
}
