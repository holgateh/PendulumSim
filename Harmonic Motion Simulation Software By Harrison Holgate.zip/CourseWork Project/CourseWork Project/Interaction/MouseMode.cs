﻿namespace CourseWork_Project
{
    public enum MouseMode
    {
        Translate,
        Pen,
        Interact,
        Line
    }
}
