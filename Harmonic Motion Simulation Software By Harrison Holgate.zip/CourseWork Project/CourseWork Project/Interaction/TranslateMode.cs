﻿namespace CourseWork_Project.Rendering
{
    public enum ZoomMode
    {
        ZoomIn,
        ZoomOut
    }
}
